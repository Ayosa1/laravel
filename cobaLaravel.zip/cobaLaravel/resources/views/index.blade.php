    @extends('layout/main')
    @section('title','Home')
        
    @section('container')
    <div class="container">
        <div class="row">
            <div class="col-10">
                <h1 class="mt-3">Hello, world!</h1>
            </div>
        </div>
    </div>
    @endsection