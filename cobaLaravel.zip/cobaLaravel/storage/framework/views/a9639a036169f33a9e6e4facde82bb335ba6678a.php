<?php $__env->startSection('title','Form Tambah Data Mahasiswa'); ?>
    
<?php $__env->startSection('container'); ?>
<div class="container">
    <div class="row">
        <div class="col-8">
            <h1 class="mt-3">Form Tambah Data Mahasiswa</h1>

            <form method="POST" action="/students">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                  <label for="nama">Nama</label>
                <input type="text" class="form-control <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="nama" placeholder="Masukan Nama" name="nama" value="<?php echo e(old('nama')); ?>">
                  <?php if ($errors->has('nama')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nama'); ?>
                  <div class="invalid-feedback">
                   <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                  <label for="nim">NIM</label>
                  <input type="text" class="form-control <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="nim" placeholder="Masukan NIM" name="nim" value="<?php echo e(old('nim')); ?>">
                  <?php if ($errors->has('nim')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('nim'); ?>
                  <div class="invalid-feedback">
                   <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="text" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email" placeholder="Masukan Email" name="email" value="<?php echo e(old('email')); ?>">
                  <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                  <div class="invalid-feedback">
                   <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <div class="form-group">
                  <label for="jurusan">Jurusan</label>
                  <input type="text" class="form-control <?php if ($errors->has('jurusan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jurusan'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="jurusan" placeholder="Masukan Jurusan" name="jurusan" value="<?php echo e(old('jurusan')); ?>">
                  <?php if ($errors->has('jurusan')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('jurusan'); ?>
                  <div class="invalid-feedback">
                   <?php echo e($message); ?>

                  </div>
                  <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                </div>
                <button type="submit" class="btn btn-primary">Tambah data</button>
              </form>
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cobaLaravel\resources\views/students/create.blade.php ENDPATH**/ ?>